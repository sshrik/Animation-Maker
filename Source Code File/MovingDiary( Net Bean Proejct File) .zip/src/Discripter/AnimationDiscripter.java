/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Discripter;

/**
 *
 * @author chj87
 */
public class AnimationDiscripter {
    private int nowDepth[];
    private int nextDepth[];
    private boolean sceneChanged;
    private double timeVar ;
    
    public final static int REMOVED = -1;
    
    
}
